<?php

$servername = "localhost";
$username = "givebirt_infotec";
$password = "encourageinfotech";
$dbname = "givebirt_infotec";

// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "brazil";

?>